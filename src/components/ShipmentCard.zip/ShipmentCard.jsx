import { FaArrowRight } from "react-icons/fa";

export default function ShipmentCard({ shipment, onView }) {
  return (
    <div className="shipment-card">
      <div className="shipment-top">
        <div>
          <h3>{shipment.id}</h3>

          <p>
            {shipment.from} → {shipment.to}
          </p>
        </div>

        <span
          className={`status ${shipment.status
            .toLowerCase()
            .replace(/\s/g, "-")}`}
        >
          {shipment.status}
        </span>
      </div>

      <div className="shipment-middle">
        <span>{shipment.type}</span>

        <span>{shipment.weight}</span>

        <span>{shipment.date}</span>
      </div>

      <button className="view-btn" onClick={onView}>
        View Details
        <FaArrowRight />
      </button>
    </div>
  );
}
